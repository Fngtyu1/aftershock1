# 余震协议｜搜打撤第三方介入机制设计

独立非官方游戏策划概念作品。参数为假设，未使用《三角洲行动》后台数据。

- `index.html`：直接用浏览器打开的可交互时间窗口原型，可通过 GitHub Pages 发布。
- `aftershock_design.pdf`：策划案，含问题、机制、数值假设、风险与验证计划。

## 发布为作品链接
1. 登录 GitHub，新建公开仓库 `aftershock-protocol`。
2. 上传 `index.html` 和 `aftershock_design.pdf` 到仓库根目录。
3. 仓库 Settings → Pages → Build and deployment → Deploy from a branch，选择 `main` / `(root)` 保存。
4. 等待部署完成后，访问 Pages 显示的实际链接，并在无痕窗口测试 PDF 链接和滑块。
5. 将实际可访问的 Pages 地址填写到腾讯网申“相关项目或作品链接”。

注意：未实际完成的玩家测试或数据实验，不应写为已完成成果。
